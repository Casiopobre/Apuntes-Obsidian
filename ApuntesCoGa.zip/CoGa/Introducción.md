# Ideas xerais
Fenómeno de **persistencia**: permitenos percibir _movemento_ (capturamos certa cantidade de imaxes por segundo)

**Tubo de Raios Catódicos**: "arráncanselle electróns dun cátodo", que, cando chocan contra a pantalla de fósforo, xeran luz
![[RaiosCatadicos.png | center | 200]]

**TCR (Terminales vectoriais)**: o haz de electróns recorre a pantalla según as ordes de debuxo.

**Terminais raster**: consisten nunha matriz na que se deciden qué pixeles teñen que estar encendidos ou apagados  --> Rasterizado
![[Rasterizado.png| | center | 400]]

**Frame/color buffer**: é unha _zona de memoria_ na que se almacena a matriz de 0 e 1 que indica os píxeles que teñen que estar encendidos ou apagados --> Imaxes
+ _Profundidade de cor_: numero de cores dispoñibles en función de cantos bits se lle poden dedicar a cada cor
==Ver diapositivas de conceptos (31)==

## Dobre buffer: 
**Problema**: ao frame buffer non lle da tempo a actualizarse antes de que cambie na pntalla
**Solución**: 2 frame buffers para ir intercambiando dunha imaxe á outra (`swap`), para non chegar a ver como se crea
![[DobreBuffer.png| center | 400]]
## Buffer de profundidade:
Permite pintar obxetos en profundidade (un detrás ou diante de outro)
**Problema**: algoritmo do pintor (oss obxetos debuxanse no orde no que chegan)
**Solución**: Buffer z 

# Introducción a OpenGL
OpenGl _interactúa específicamente coa GPU_ do sistema.
É unha biblioteca de C (**API**) que **non ten xestor de ventás**, polo que necesita _librarías auxiliares_ para xestionar as ventás (contexto de traballo OpenGL): Glfw (ver. OpenGL > 3.3)

### Modelo cámara sintética
É o método que ten OpenGL a grandes rasgos para xerar a escena.
![[CamaraSintetica.png| center | 500]]
Consta da escena (situación dos obxetos), da cámara (posición e orientación) e da proxección (enfoque da cámara)

### APP+GPU operacións fixas (modo inmediato)
As escenas parten dun conxunto de vétices (obxetos), que, ao inicio, se trasladan á posición desexada (obtemos a escena = vertices de todos os obxetos colocados na sua posición). Despois compomos as caras (ensamblado), especificando como un conxunto de vértices se deben unir para formalas. Agora faise un proceso de raster: bárrese as liñas de cada cara para atopar como se representan na pantalla, obtendo fragmentos. Despois coloreamos os fragmentos en función de certos algoritmos (shaders). A patrir de ahí, só nos queda mirar que obxeto está mais preto da pantalla para pintalo (z-buffer).
![[EsquemaOperacionsFixas.png]]

### Retained mode
Implementa os shaders, que se meten entre o proceso de colocación dos vértices e entre o proceso de coloración dos fragmentos, xa que as GPUs modernas implementan moitas características que lles permiten "operar con estes elementos moi eficientemente"

### Construcción de obxetos





